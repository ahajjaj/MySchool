package com.example.myschool;

public class Constants {
    public static  final String ROOT_URL="https://myschoolaa.000webhostapp.com/";
    public static  final String URL_REGISTER= ROOT_URL+ "registerAccount.php";
    public static  final String URL_LOGIN= ROOT_URL+ "loginAccount.php";

}